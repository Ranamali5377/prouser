# USAMA
# SOMI-BRAND
<p align="center"><a href="https://github.com/SOMI-BRAND">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=SOMI-BRAND&show_icons=true&include_all_commits=true&theme=react&cache_seconds=3200&hide_border=true" /></a>

&nbsp;&nbsp;&nbsp;

<a href="https://github.com/SOMI-BRAND"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=SOMI-BRAND&layout=compact&theme=react&hide_border=true" />

</a></p>

<h2><b><i>Hello I'm Usama✨</i></b></h2>

<b><i>💻 I'm a Student & I Like programming</i></b>

<h3><b><i> About me 🧠 :</i></b></h3>

<li> 🇵🇰 <i> From Pakistan  </i></li>

<h3><b><i>🏆 Github Statistics :</i></b></h3>

<a href="https://github.com/SOMI-BRAND"><img width=550 src="https://github-profile-trophy.vercel.app/?username=SOMI-BRAND&theme=dracula&no-frame=true&title=Followers,Stars,Commit,Repository,Issues"/></a>

<h3><b><i>🏆 Profile Statistics :</i></b></h3>

<a href="https://github.com/SOMI-BRAND"><img height="25" title="Counter" src="https://komarev.com/ghpvc/?username=SOMI-BRAND&color=blueviolet&style=flat-square"></a>
<h1 align="center"> I'm USAMA (SOMI)</h1>
<p align="center">
     
     <i> <b> SOMI HIGH RATED BRAND </b> </i>
</p>

<p align="center">
<img src="https://1.bp.blogspot.com/-gIpMNlv2VFc/YJXIvfonyHI/AAAAAAAAAYI/u8u9qmxEkEAqK4wwJltIqamQOQZsocngwCLcBGAsYHQ/s1280/20210508_035826.jpg">
</p>
<p align="center">
<i> <b> FUCK THE SYSTEM </b> </i>
</p>


## CONNECT WITH US :


<a href="https://github.com/SOMI-BRAND"><img title="Github" src="https://img.shields.io/badge/SOMI-BRAND-brightgreen?style=for-the-badge&logo=github"></a>

